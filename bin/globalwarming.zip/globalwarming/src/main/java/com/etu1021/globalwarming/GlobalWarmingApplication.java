package com.etu1021.globalwarming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalWarmingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalWarmingApplication.class, args);
	}

}
