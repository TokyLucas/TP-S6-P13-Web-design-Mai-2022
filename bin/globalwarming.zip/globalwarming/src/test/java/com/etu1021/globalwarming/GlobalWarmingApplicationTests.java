package com.etu1021.globalwarming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalWarmingApplicationTests {

	@Test
	void contextLoads() {
	}

}
